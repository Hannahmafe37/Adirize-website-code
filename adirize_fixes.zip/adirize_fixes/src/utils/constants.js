export const LINKS = {
  login: "https://join.adirize.com/login",
  presale: "https://join.adirize.com/register",
  whitepaper: "https://adirize.com/ADIRIZE%20DAO%20White%20Paper%20(2).pdf",
  telegram: "https://t.me/AdirizeDAO_Official",
  twitter: "https://twitter.com/AdirizeDAO",
};

export const largeScreenClasses = "!max-w-6xl lg:!mx-auto";
